const bodyParser = require("body-parser");
const express = require("express");
const app = express();
const mongoose = require("mongoose");

app.use(bodyParser.urlencoded({ extended: true }));
//app.use(express.static('public'));


//mongodb+srv://user1:N32ZV0Ceki0E6V3L@mandar.vax261g.mongodb.net/wtl?retryWrites=true&w=majority
//mongodb+srv://vedingale:Qwerty321@ved.wsyitih.mongodb.net/WTL?retryWrites=true&w=majority
mongoose.connect(
  "mongodb+srv://vedingale:Qwerty321@ved.wsyitih.mongodb.net/WebT",
  { useNewUrlParser: true },
  { useUnifiedTopology: true }
)

const EcommSchema = {
  name: String,
  phone: Number,
  // phone: {
  //   type: Number,
  //   validate: {
  //     validator: Number.isInteger,
  //     message: "ERROR"
  //   }
  // }, 
  order: String,
};

const Ecom = mongoose.model("WebT", EcommSchema);

// app.get("/", function (req, res) {
//   res.sendFile(__dirname + "/index.html");
// });

app.get("/check", async function (req, res) {
  let ecart;
  try {
    ecart = await Ecom.find();
  } catch (error) {
    console.log(error);
  }

  if (!ecart) {
    return res.status(404).json({ message: "No Order Found!!" });
  }
  return res.status(200).json({ ecart });
});

app.post("/add", function (req, res) {
  let newEcart = new Ecom({
    name: req.body.name,
    phone: req.body.phone,
    order: req.body.order,
  });
  newEcart.save();
  res.redirect("http://127.0.0.1:5500/index.html");
});

// app.get("/" , (req,res)=>{
//     res.sendFile(__dirname+"/index.html");
// });


app.listen(5000, function () {
  console.log("server is running on 5000");
});